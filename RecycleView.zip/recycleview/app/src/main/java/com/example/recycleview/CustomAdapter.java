package com.example.recycleview;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder>{
    private ArrayList<DataModel> dataSet;
    public CustomAdapter(ArrayList<DataModel> dataSet){
        this.dataSet = dataSet;
    }
    public static class MyViewHolder extends RecyclerView.ViewHolder{
        CardView cardView;
        TextView textViewName;
        TextView textViewRole;
        ImageView imageViewPic;
        public  MyViewHolder(View itemView){
            super(itemView);
            cardView = (CardView) itemView.findViewById(R.id.card_view);
            textViewName = (TextView) itemView.findViewById(R.id.textViewName);
            textViewRole = (TextView) itemView.findViewById(R.id.textViewRole);
            imageViewPic = (ImageView) itemView.findViewById(R.id.imageView);
        }

    }
    @NonNull
    @Override
    public CustomAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cards_layout,parent,false);
        MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder viewHolder, int listPosition) {
        TextView textViewName = viewHolder.textViewName;
        TextView textViewDescription =viewHolder.textViewRole;
        ImageView imageView = viewHolder.imageViewPic;
        CardView cardView = viewHolder.cardView;
        textViewName.setText(dataSet.get(listPosition).getName());
        textViewDescription.setText(dataSet.get(listPosition).getRole());
        imageView.setImageResource(dataSet.get(listPosition).getImage());
        imageView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Log.i("Check", String.valueOf(viewHolder.getAdapterPosition()));
                Bundle bundle = new Bundle();
                bundle.putInt("id",viewHolder.getAdapterPosition());
                Navigation.findNavController(v).navigate(R.id.action_recycler_layout_to_itemDescriptionFragment,bundle);
            }
        });

    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }
}
