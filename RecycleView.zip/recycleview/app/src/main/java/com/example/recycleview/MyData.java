package com.example.recycleview;

public class MyData {
    static String[] nameArray = {"Ashe","Brock","Misty","Pikachu","Charizard","Jessie","James","Meow"};
    static String[] RoleArray = {"Main Character","Side Character","Side Character","Pokemon","Pokemon","Antagonist","Antagonist","Antagonist"};
    static String[] descriptionArray = {"Ashe Ketchum is the main character and his goal is to catch all the pokemons!",
    "Brock is the first gym leader and after Ashe beat him he join him on his journey to catch all pokemons",
    "Misty is the water gym leader and after Ashe beat her she join him on his journey to catch all pokemons",
    "Pikachu is one of Ashe's pokemons, it's also his very first one and his best friend",
    "Charizard is one of Ashe's pokemons, it's the third evoltion of Charmander, one of the starter pokemons",
    "Jessie is one of the three villains in the show, she is a part of Team Rocket and their goal is to rule to world",
    "James is on of the three villains in the show, he is a part of Team Rocket and their goal is to rule to world",
    "Meow is on of the three villains in the show, he is also a cat like pokemon who can talk, he is a part of Team Rocket and their goal is to rule the world"};
    static Integer[] drawableArray = {R.drawable.ashe_ketchum,R.drawable.brock,R.drawable.misty,R.drawable.pikachu,R.drawable.charizard,R.drawable.jessie,
            R.drawable.james,R.drawable.meowth};

    static Integer[] id_ = {0, 1, 2, 3, 4, 5, 6, 7};

}
