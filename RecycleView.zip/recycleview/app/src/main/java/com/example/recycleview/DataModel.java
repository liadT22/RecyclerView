package com.example.recycleview;

public class DataModel {
    String name;
    String role;
    String description;
    int id_;
    int image;

    public DataModel(String name, String description, String role, int id_, int image) {
        this.name = name;
        this.role = role;
        this.description = description;
        this.id_ = id_;
        this.image=image;
    }


    public String getName() {
        return name;
    }

    public String getRole() {return role;}

    public String getDescription() {return description;}

    public int getImage() {
        return image;
    }

    public int getId() {
        return id_;
    }
}
